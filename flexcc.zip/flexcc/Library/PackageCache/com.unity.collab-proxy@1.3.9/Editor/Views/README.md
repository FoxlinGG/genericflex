# Views
In this directory, we have all of the interfaces and implementations of the Views in the package's **MVP** architecture.

ListAdapters are also stored under `Adapters/` as they are considered a sub-View.
